package com.example.tour;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.tour.adapter.Destination;
import com.example.tour.adapter.DestinationAdapter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DestinationsActivity extends AppCompatActivity {
    private ArrayList<Destination> destinationArrayList;
    private DestinationAdapter destinationAdapter;
    RecyclerView recyclerView;
    ProgressDialog pDialog;
    Context context=null;

    String cid ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destinations);
        recyclerView=findViewById(R.id.rview1);


        context = getApplicationContext();
        list();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        cid  = getIntent().getStringExtra("id");
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    public void list()
    {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("downloading, please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                finish();
            }
        });
        pDialog.show();

//        String url = "https://project.igaptechnologies.com/api/products_api.php";
        //String url="http://192.168.14.1/TourProject/api/destinations_api.php";

        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, DBClass.destination_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pDialog.dismiss();
                        Log.d("Response ", ">> " + response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonData = jsonObject.getJSONArray("data");
                            destinationArrayList = new ArrayList<>();
                            for (int i = 0; i < jsonData.length(); i++) {
                                Destination destination = new Destination();
                                JSONObject jo = jsonData.getJSONObject(i);
                                destination.id = jo.getString("id");
                                destination.name = jo.getString("name");
                                destination.price = jo.getString("package");
                              //  destination.description = jo.getString("description");
                                destination.image = jo.getString("pic");


                                destinationArrayList.add(destination);
                            }
                            destinationAdapter = new DestinationAdapter(getApplicationContext(), destinationArrayList);

                            recyclerView.setLayoutManager(new LinearLayoutManager(DestinationsActivity.this));
                            recyclerView.setAdapter(destinationAdapter);
                        } catch (Exception e) {
                            Log.e("Exception",""+ e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Exception",""+ error);
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("cid", cid);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

}