package com.example.tour;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.tour.adapter.Tour;
import com.example.tour.adapter.TourAdapter;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.slider.Slider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public ImageSlider imageSlider;
    public RecyclerView recyclerView;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    public DrawerLayout drawerLayout;
    private ArrayList<Tour> tourArrayList;
    private TourAdapter tourAdapter;
    ProgressDialog pDialog;
    Context context=null;
    NavigationView navigationView;

   LinearLayout bookLayout,logoutLayout,profileLayout;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawerLayout=findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,R.string.nav_open,R.string.nav_close);
        navigationView=findViewById(R.id.navigationView);
        //pass the Open and Close toggle for the drawer layout listener
        //to toggle the buttons
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        //to make navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.purple)));

        imageSlider=findViewById(R.id.image_slider);
        ArrayList<SlideModel>slideModels=new ArrayList<>();
        slideModels.add(new SlideModel(R.drawable.kashmir1, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.italy2, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.kashmir2, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.paris, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.nepal, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.londonbrg, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.maldives, ScaleTypes.FIT));
        slideModels.add(new SlideModel(R.drawable.rome, ScaleTypes.FIT));
        imageSlider.setImageList(slideModels,ScaleTypes.FIT);


        recyclerView=findViewById(R.id.rview);
        context = getApplicationContext();
        logoutLayout=findViewById(R.id.logoutLayout);
        bookLayout=findViewById(R.id.bookLayout);
        profileLayout=findViewById(R.id.profileLayout);

        list();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int id=item.getItemId();

                if(id==R.id.nav_home)
                {
                    Intent intent=new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                    return true;
                }
                else
                if(id==R.id.nav_profile)
                {
                    Intent intent=new Intent(MainActivity.this, ProfileActivity.class);
                    startActivity(intent);
                    return true;
                }
                else
                if(id==R.id.nav_bookings)
                {
                    Intent intent=new Intent(MainActivity.this, BookingActivity.class);
                    startActivity(intent);
                    return true;
                }
                else
                if(id==R.id.nav_logout)
                {
                    String query = "DELETE FROM Configuration";
                    DBClass.execNonQuery(query);
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                }
                return true;

            }
        });

        logoutLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                builder.setTitle("Logout");
                builder.setMessage("Are you sure want to Logout? ");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        String query = "DELETE FROM Configuration";
                        DBClass.execNonQuery(query);
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                builder.show();


            }
        });
        bookLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, BookingActivity.class);
                startActivity(intent);

            }
        });
        profileLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(intent);

            }
        });

    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    public void list()
    {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("downloading, please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                finish();
            }
        });
        pDialog.show();



      //  String url = "https://project.igaptechnologies.com/api/products_api.php";
       // String url="http://192.168.1.34/TourProject/api/categories_api.php";


        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, DBClass.categories_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pDialog.dismiss();
                        Log.d("Response ", ">> " + response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonData = jsonObject.getJSONArray("data");
                            tourArrayList = new ArrayList<>();
                            for (int i = 0; i < jsonData.length(); i++) {
                                Tour tour = new Tour();
                                JSONObject jo = jsonData.getJSONObject(i);
                                tour.id = jo.getString("id");
                                tour.name = jo.getString("name");
                               // tour.price = jo.getString("price");
                                tour.image = jo.getString("pic");


                                tourArrayList.add(tour);
                            }
                            tourAdapter = new TourAdapter(getApplicationContext(), tourArrayList);

                            recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
                            recyclerView.setAdapter(tourAdapter);
                        } catch (Exception e) {
                            Log.e("Exception",""+ e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Exception",""+ error);
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(actionBarDrawerToggle.onOptionsItemSelected(item))
        {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}