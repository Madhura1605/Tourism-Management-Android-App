package com.example.tour.adapter;


    public class Destination {
        public  String id = "";
        public String name = "";
        public  String description = "";
        public String price = "";
        public String image="";
}
