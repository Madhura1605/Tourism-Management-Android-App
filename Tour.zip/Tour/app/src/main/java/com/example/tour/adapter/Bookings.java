package com.example.tour.adapter;

public class Bookings {
    public String id = "";
    public String user = "";
    public String mobileno = "";
    public String email = "";
    public String name = "";
    public String price = "";
    public String image = "";
    public String datetime = "";
}
