package com.example.tour;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegistrationActivity extends AppCompatActivity {

    EditText etxtname, etxtemail, etxtmobileno, etxtPassword;
    String id = "", name = "", email = "", mobileno = "", password = "";
    ProgressDialog pDialog;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        etxtname = findViewById(R.id.etxtname);
        etxtemail = findViewById(R.id.etxtemail);
        etxtmobileno = findViewById(R.id.etxtmobileno);
        etxtPassword = findViewById(R.id.etxtPassword);

    }

    public void btnSubmit(View view) {

        String name = etxtname.getText().toString();
        String email = etxtemail.getText().toString();
        String mobileno = etxtmobileno.getText().toString();
        String password = etxtPassword.getText().toString();

        if (name.isEmpty()) {
            etxtname.setError("Please enter name");
            etxtname.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            etxtemail.setError("Please enter email");
            etxtemail.requestFocus();
            return;
        }
        if (mobileno.isEmpty()) {
            etxtmobileno.setError("Please enter mobile no.");
            etxtmobileno.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            etxtPassword.setError("Please enter password");
            etxtPassword.requestFocus();
            return;
        }
        pDialog = new ProgressDialog(RegistrationActivity.this);
        pDialog.setMessage("validating your details, please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();

       // String url = "https://project.igaptechnologies.com/api/registration_api.php";
      //  String url="http://192.168.14.1/project/api/registration_api.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, DBClass.registration_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null;
                        Log.d("Response", ">> " + response);
                        pDialog.dismiss();
                        try {
                            jsonObject = new JSONObject(response);


                            if (jsonObject.getString("status").equals("success")) {
                                Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(getApplicationContext(), "Registration Failed...", Toast.LENGTH_LONG).show();

                            }
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pDialog.dismiss();
                Log.e("Exception", error.toString());
                Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("mobileno", mobileno);
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
}