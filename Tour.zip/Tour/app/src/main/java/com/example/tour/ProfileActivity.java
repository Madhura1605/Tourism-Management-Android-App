package com.example.tour;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {
    TextView txtName, txtMobileNo, txtEmail;
    ImageView imageView;
    String id="0";
    String name="", email="",mobileno="";


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        txtName=findViewById(R.id.txtName);
        txtEmail = findViewById(R.id.txtEmail);
        txtMobileNo = findViewById(R.id.txtMobileNo);
       // imageView = findViewById(R.id.img);

        id  = getIntent().getStringExtra("id");
        String query = "SELECT CValue FROM Configuration WHERE CName = 'id'";  //fetching id and storing into userid
        id = DBClass.getSingleValue(query);

        getdetails();
      //  String profilename = getIntent().getStringExtra("profilename");
     //   setTitle(profilename);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp()
    {
        onBackPressed();
        return true;
    }

    public void getdetails()
    {
      /*  pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading data, please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();
       */

        // String url = "https://project.igaptechnologies.com/api/getproduct_api.php";
        //String url="http://192.168.14.1/TourProject/api/get_destination.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, DBClass.profile_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null;
                        Log.d("Response", ">> "+response);
                        // pDialog.dismiss();
                        try {
                            jsonObject = new JSONObject(response);

                            if(jsonObject.getString("status").equals("success")) {
                                txtName.setText(jsonObject.getString("name"));
                               // txtEmail.setText("\u20B9 "+jsonObject.getString("email"));
                                txtEmail.setText(jsonObject.getString("email"));
                               // price = jsonObject.getString("package");
                                txtMobileNo.setText(jsonObject.getString("mobileno"));
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "No Information found...", Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();
                            Log.e("Exception", ">> "+e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //pDialog.dismiss();
                        Log.e("Exception", error.toString());
                        Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                Log.e("Params", params.toString());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

}
