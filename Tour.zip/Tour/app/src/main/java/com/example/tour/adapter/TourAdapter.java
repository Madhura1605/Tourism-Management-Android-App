package com.example.tour.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.tour.DBClass;
import com.example.tour.DestinationDetailsActivity;
import com.example.tour.DestinationsActivity;
import com.example.tour.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TourAdapter extends RecyclerView.Adapter<TourAdapter.MyViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<Tour> tourArrayList;
    Context context;

    public TourAdapter(Context ctx, ArrayList<Tour> tourArrayList){

        inflater = LayoutInflater.from(ctx);
        this.tourArrayList = tourArrayList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.tours, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public int getItemViewType(int position)
    {
        return position;
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.txtTitle.setText(tourArrayList.get(position).name);
      //  holder.txtPrice.setText("\u20B9 "+tourArrayList.get(position).price);

       // String url = "https://project.igaptechnologies.com/";
        //String url = "http://192.168.1.34/TourProject/";



        final Uri uri = Uri.parse(DBClass.url +"categorypics/"+tourArrayList.get(position).image+".png");
        Picasso.get().load(uri).into(holder.imageView);
       holder.layoutTour.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View view) {
               try
               {
                   Intent intent = new Intent(context, DestinationsActivity.class);
                   intent.putExtra("id", "" + tourArrayList.get(position).id);
                    intent.putExtra("name", "" + tourArrayList.get(position).name);
                  intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                 context.startActivity(intent);
               }
                catch(Exception ex) {
                    Log.e("Ex", "onClick: " + ex);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return tourArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txtTitle;
        ImageView imageView;
        LinearLayout layoutTour;


        public MyViewHolder(View view) {
            super(view);
            context = itemView.getContext();
            txtTitle = (TextView) view.findViewById(R.id.tourTitle);
            imageView = (ImageView) view.findViewById(R.id.tourImg);
           layoutTour = (LinearLayout) view.findViewById(R.id.layoutTour);

        }
    }
}
