package com.example.tour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        createDatabase();
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
               /* Intent intent=new Intent(SplashscreenActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                */
                Intent intent;
                String query = "SELECT * FROM Configuration";
                if(DBClass.checkIfRecordExist(query))
                {
                    intent = new Intent(SplashScreenActivity.this,MainActivity.class);
                }
                else {
                    intent = new Intent(SplashScreenActivity.this,LoginActivity.class);
                }
                startActivity(intent);
                finish();
            }
        },5000);
    }
    public void createDatabase() {
        String query;
        DBClass.database = openOrCreateDatabase(DBClass.dbname, MODE_PRIVATE, null);
        query = "CREATE TABLE IF NOT EXISTS Configuration(CName VARCHAR, CValue VARCHAR);";
        DBClass.execNonQuery(query);

    }
}

