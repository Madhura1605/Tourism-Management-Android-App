package com.example.tour;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DestinationDetailsActivity extends AppCompatActivity {
    TextView txtTitle, txtPrice, txtDesc;
    ImageView imageView;
    String id="0";
    String userid="", price="";
    ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination_details);
        txtTitle=findViewById(R.id.txtTitle);
        txtPrice = findViewById(R.id.txtPrice);
        txtDesc = findViewById(R.id.txtDesc);
        imageView = findViewById(R.id.img);

        id  = getIntent().getStringExtra("id");
        String query = "SELECT CValue FROM Configuration WHERE CName = 'id'";  //fetching id and storing into userid
        userid = DBClass.getSingleValue(query);

        getdetails();
        String destinationname = getIntent().getStringExtra("destinationname");
        setTitle(destinationname);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public void getdetails()
    {
      /*  pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading data, please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();

       */
       // String url = "https://project.igaptechnologies.com/api/getproduct_api.php";
        //String url="http://192.168.14.1/TourProject/api/get_destination.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, DBClass.getDestination_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null;
                        Log.d("Response", ">> "+response);
                       // pDialog.dismiss();
                        try {
                            jsonObject = new JSONObject(response);

                            if(jsonObject.getString("status").equals("success")) {
                                txtTitle.setText(jsonObject.getString("name"));
                                txtPrice.setText("\u20B9 "+jsonObject.getString("package"));
                                price = jsonObject.getString("package");
                                txtDesc.setText(jsonObject.getString("description"));
                                String imagename = jsonObject.getString("pic");
                                final Uri uri = Uri.parse(DBClass.url+"destinationpics/"+imagename+".png");
                                Picasso.get().load(uri).into(imageView);
                                Log.d("URI "," >>"+uri);

                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "No Information found...", Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();
                            Log.e("Exception", ">> "+e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       pDialog.dismiss();
                        Log.e("Exception", error.toString());
                        Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                Log.e("Params", params.toString());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    public void btnBookNow(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Booking");
        builder.setMessage("Are you sure want to Book the Tour ? ");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                booknow();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        builder.show();
    }
    public void booknow()
    {

        pDialog = new ProgressDialog(DestinationDetailsActivity.this);
        pDialog.setMessage("validating your details, please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();

       // String url="https://project.igaptechnologies.com/api/placeorder_api.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, DBClass.place_booking_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject jsonObject = null;
                        Log.d("Response", ">> "+response);
                        pDialog.dismiss();
                        try
                        {
                            jsonObject = new JSONObject(response);


                            if (jsonObject.getString("status").equals("success"))
                            {
                                /*Intent intent = new Intent(DestinationDetailsActivity.this, DestinationsActivity.class);
                                startActivity(intent);
                                finish();

                                 */
                                Toast.makeText(getApplicationContext(), "Tour Booked...", Toast.LENGTH_LONG).show();

                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();

                            }
                        }
                        catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pDialog.dismiss();
                Log.e("Exception", error.toString());
                Toast.makeText(getApplicationContext(), "Check Internet Connection...", Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<>();
                params.put("userid", userid);
                params.put("destid", id);
                params.put("package", price);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);


    }

}