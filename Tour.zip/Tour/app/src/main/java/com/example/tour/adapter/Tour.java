package com.example.tour.adapter;

public class Tour {
    public  String id = "";
    public String name = "";
    public String image="";
}
