package com.example.tour;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBClass extends SQLiteOpenHelper {

    public static String dbname = "tourism";
    public static SQLiteDatabase database;

   // public static String url = "https://project.igaptechnologies.com/";
   // public static String url="http://192.168.1.34/TourProject/";
    //public static String url="http://192.168.14.1/TourProject/";
    //public static String url="http://192.168.181.1/TourProject/";
    public static String url="http://192.168.177.1/TourProject/";

    public static String categories_url = url + "api/categories_api.php";

    public static String destination_url = url + "api/destination_api.php";
    public static String login_url = url + "api/login_api.php";
    public static String registration_url = url + "api/registration_api.php";
    public static String getDestination_url = url + "api/get_destination_api.php";
    public static String booking_url = url + "api/booking_api.php";
    public static String place_booking_url = url + "api/place_booking_api.php";
    public static String profile_url = url + "api/profile_api.php";



    public DBClass(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public static Cursor getCursorData(String query){
        //Log.d("SQuery", query);
        Cursor res =  database.rawQuery(query, null);
        return res;
    }
    public static String getSingleValue(String query) {
        try {
            Cursor res = getCursorData(query);
            String value = "";
            if (res.moveToNext()) {
                return res.getString(0);
            }
            return value;
        }
        catch (Exception ex)
        {
            return "";
        }
    }
    public static boolean checkIfRecordExist(String query){
        //Log.e("CheckQuery", query);
        Cursor res =  database.rawQuery(query, null );
        if(res.getCount() > 0)
            return true;
        else
            return false;
    }
    public static void execNonQuery(String query){
        //Execute Insert, Update, Delete, Create table queries
        //Log.e("Query", query);
        database.execSQL(query);
    }
}

