package com.example.tour;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.tour.adapter.Bookings;
import com.example.tour.adapter.BookingsAdapter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BookingActivity extends AppCompatActivity {
    private ArrayList<Bookings> bookingsArrayList;
    private BookingsAdapter bookingsAdapter;
    RecyclerView rview2;
    ProgressDialog pDialog;
    String userid="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);
        rview2 = findViewById(R.id.rview2);

        String query = "SELECT CValue FROM Configuration WHERE CName = 'id'";
        userid = DBClass.getSingleValue(query);


        bookings();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    public void bookings()
    {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("downloading, please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                finish();
            }
        });
        pDialog.show();
       // String url = "https://project.igaptechnologies.com/api/orders_api.php";


        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.POST, DBClass.booking_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pDialog.dismiss();
                        Log.d("Response ", ">> " + response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonData = jsonObject.getJSONArray("data");
                            bookingsArrayList = new ArrayList<>();
                            for (int i = 0; i < jsonData.length(); i++) {
                                Bookings order = new Bookings();
                                JSONObject jo = jsonData.getJSONObject(i);
                                order.id = jo.getString("id");
                                order.user = jo.getString("user");
                                order.mobileno = jo.getString("mobileno");
                                order.email = jo.getString("email");
                                order.image = jo.getString("pic");
                                order.name = jo.getString("name");
                                order.price = jo.getString("total");
                                //order.datetime = jo.getString("orderedon");
                                bookingsArrayList.add(order);
                            }
                            bookingsAdapter = new BookingsAdapter(getApplicationContext(), bookingsArrayList);
                            StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL);
                            rview2.setLayoutManager(layoutManager);
                            rview2.setAdapter(bookingsAdapter);
                        } catch (Exception e) {
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("userid", userid);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
}