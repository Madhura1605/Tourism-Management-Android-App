package com.example.tour.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.tour.DBClass;
import com.example.tour.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class BookingsAdapter extends RecyclerView.Adapter<BookingsAdapter.MyViewHolder> {


        private LayoutInflater inflater;
        private ArrayList<Bookings> bookingsArrayList;
        Context context;

    public BookingsAdapter(Context ctx, ArrayList<Bookings> orderArrayList){

            inflater = LayoutInflater.from(ctx);
            this.bookingsArrayList = orderArrayList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = inflater.inflate(R.layout.booking, parent, false);
            MyViewHolder holder = new MyViewHolder(view);
            return holder;
        }


        @Override
        public int getItemViewType(int position)
        {
            return position;
        }

        @SuppressLint("ResourceAsColor")
        @Override
        public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            String userdetails = bookingsArrayList.get(position).user + "  -  " +bookingsArrayList.get(position).mobileno;
            holder.txtUserDetails.setText(userdetails);

            String destinationdetails = bookingsArrayList.get(position).name + "  -  \u20B9" +bookingsArrayList.get(position).price;
            holder.txtDestinationDetails.setText(destinationdetails);


            final Uri uri = Uri.parse(DBClass.url+"destinationpics/"+bookingsArrayList.get(position).image+".png");
            Picasso.get().load(uri).into(holder.imageView);
        }

        @Override
        public int getItemCount() {
            return bookingsArrayList.size();
        }

        class MyViewHolder extends RecyclerView.ViewHolder {

            TextView txtUserDetails, txtDestinationDetails, txtBookedon;
            ImageView imageView;


            public MyViewHolder(View view) {
                super(view);
                context = itemView.getContext();
                txtUserDetails = (TextView) view.findViewById(R.id.txtUserDetails);
                txtDestinationDetails = (TextView) view.findViewById(R.id.txtDestinationDetails);
                imageView = (ImageView) view.findViewById(R.id.imgIcon);

            }
        }


    }

